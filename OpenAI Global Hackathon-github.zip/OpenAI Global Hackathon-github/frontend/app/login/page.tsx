'use client';

import { FormEvent, useState } from 'react';
import './login.css';

type Mode = 'login' | 'register';

export default function LoginPage() {
  const [mode, setMode] = useState<Mode>('login');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError('');
    setSubmitting(true);
    const form = new FormData(event.currentTarget);
    try {
      const response = await fetch(`/api/auth/${mode}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: form.get('name'),
          email: form.get('email'),
          password: form.get('password'),
        }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        setError(data.error || 'No se pudo completar la solicitud');
        return;
      }
      window.location.assign('/');
    } catch {
      setError('No hay conexión con el servidor. Intenta de nuevo.');
    } finally {
      setSubmitting(false);
    }
  }

  const isRegister = mode === 'register';

  return (
    <div className="auth-shell">
      <form className="auth-card" onSubmit={handleSubmit}>
        <div className="auth-brand"><span className="auth-logo">S</span>Syllabot</div>
        <h1>{isRegister ? 'Crea tu cuenta' : 'Vuelve a aprender'}</h1>
        <p className="auth-muted">
          {isRegister ? 'Tu espacio, tus rutas y tu conversación con Cila.' : 'Tu progreso te espera.'}
        </p>

        {isRegister && (
          <label>
            Nombre
            <input name="name" type="text" autoComplete="name" required minLength={2} maxLength={80} />
          </label>
        )}
        <label>
          Correo
          <input name="email" type="email" autoComplete="email" required placeholder="tu@correo.com" />
        </label>
        <label>
          Contraseña
          <input
            name="password"
            type="password"
            autoComplete={isRegister ? 'new-password' : 'current-password'}
            required
            minLength={8}
            maxLength={128}
            placeholder="Mínimo 8 caracteres"
          />
        </label>

        {error && <p className="auth-error" role="alert">{error}</p>}

        <button className="auth-primary" type="submit" disabled={submitting}>
          {submitting ? 'Un momento…' : isRegister ? 'Registrarme' : 'Iniciar sesión'}
        </button>

        <button
          className="auth-link"
          type="button"
          onClick={() => { setMode(isRegister ? 'login' : 'register'); setError(''); }}
        >
          {isRegister ? '¿Ya tienes cuenta? Inicia sesión' : '¿Nuevo en Syllabot? Crea tu cuenta'}
        </button>
      </form>
    </div>
  );
}
