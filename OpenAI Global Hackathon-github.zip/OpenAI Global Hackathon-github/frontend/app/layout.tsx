import type { Metadata } from 'next';
import '@copilotkit/react-ui/styles.css';
import './globals.css';

export const metadata: Metadata = {
  title: 'Syllabot — Aprende con dirección',
  description: 'Interfaz de Syllabot conectada al backend de Syllabot (RAG, OpenRouter, Qdrant, Neo4j)',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="es">
      <body>{children}</body>
    </html>
  );
}
