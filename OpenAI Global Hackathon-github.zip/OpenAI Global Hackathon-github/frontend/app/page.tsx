import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { SESSION_COOKIE, fetchSessionUser } from './api/auth/session';
import Workspace from './workspace';

export const dynamic = 'force-dynamic';

export default async function Home() {
  const token = (await cookies()).get(SESSION_COOKIE)?.value;
  const user = await fetchSessionUser(token);
  if (!user) redirect('/login');
  return <Workspace />;
}
