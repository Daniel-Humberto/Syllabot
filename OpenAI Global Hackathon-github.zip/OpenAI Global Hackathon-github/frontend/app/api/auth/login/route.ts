import { NextRequest } from 'next/server';
import { forwardCredentials } from '../session';

export const dynamic = 'force-dynamic';

export function POST(request: NextRequest) {
  return forwardCredentials(request, '/auth/login');
}
