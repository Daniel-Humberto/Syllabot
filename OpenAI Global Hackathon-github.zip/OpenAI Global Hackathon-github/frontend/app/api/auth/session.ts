import { NextRequest, NextResponse } from 'next/server';

export const SESSION_COOKIE = 'cilabot_session';
const SESSION_MAX_AGE_SECONDS = 7 * 24 * 60 * 60;

export function backendUrl(path: string): URL {
  return new URL(path, process.env.BACKEND_INTERNAL_URL || 'http://localhost:3000');
}

function isHttps(request: NextRequest): boolean {
  return request.headers.get('x-forwarded-proto') === 'https' || request.nextUrl.protocol === 'https:';
}

export async function forwardCredentials(request: NextRequest, path: '/auth/login' | '/auth/register') {
  const body = await request.json().catch(() => ({}));
  const upstream = await fetch(backendUrl(path), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
    cache: 'no-store',
    signal: AbortSignal.timeout(15_000),
  });
  const data = await upstream.json().catch(() => ({}));
  if (!upstream.ok || typeof data.token !== 'string') {
    return NextResponse.json({ error: data.error || 'No se pudo iniciar sesión' }, { status: upstream.status || 502 });
  }

  const response = NextResponse.json({ user: data.user }, { status: upstream.status });
  response.cookies.set(SESSION_COOKIE, data.token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: isHttps(request),
    path: '/',
    maxAge: SESSION_MAX_AGE_SECONDS,
  });
  return response;
}

export async function fetchSessionUser(token: string | undefined) {
  if (!token) return null;
  const upstream = await fetch(backendUrl('/auth/me'), {
    headers: { Authorization: `Bearer ${token}` },
    cache: 'no-store',
    signal: AbortSignal.timeout(5_000),
  }).catch(() => null);
  if (!upstream?.ok) return null;
  const data = await upstream.json().catch(() => ({}));
  return data.user as { id: string; email: string; name: string } | null;
}
