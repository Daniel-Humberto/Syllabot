import { NextRequest } from 'next/server';
import { SESSION_COOKIE } from '../../auth/session';

export const dynamic = 'force-dynamic';

async function proxy(request: NextRequest, context: { params: Promise<{ path: string[] }> }) {
  const { path } = await context.params;
  const backend = process.env.BACKEND_INTERNAL_URL || 'http://localhost:3000';
  const target = new URL(`/${path.map(encodeURIComponent).join('/')}`, backend);
  target.search = request.nextUrl.search;

  const headers = new Headers();
  for (const name of [
    'content-type',
    'x-slack-request-timestamp',
    'x-slack-signature',
    'x-telegram-bot-api-secret-token',
    'x-signature-ed25519',
    'x-signature-timestamp',
  ]) {
    const value = request.headers.get(name);
    if (value) headers.set(name, value);
  }
  const sessionToken = request.cookies.get(SESSION_COOKIE)?.value;
  if (sessionToken) headers.set('authorization', `Bearer ${sessionToken}`);

  const upstream = await fetch(target, {
    method: request.method,
    headers,
    body: request.method === 'GET' || request.method === 'HEAD' ? undefined : await request.arrayBuffer(),
    cache: 'no-store',
    // Una ruta ejecuta Planeador → búsquedas/transcripts → Curador.
    signal: AbortSignal.timeout(130_000),
  });
  const responseHeaders = new Headers();
  const contentType = upstream.headers.get('content-type');
  if (contentType) responseHeaders.set('content-type', contentType);
  const hasNoBody = [204, 205, 304].includes(upstream.status);
  const body = hasNoBody ? null : await upstream.arrayBuffer();
  return new Response(body, { status: upstream.status, headers: responseHeaders });
}

export const GET = proxy;
export const POST = proxy;
export const PUT = proxy;
export const PATCH = proxy;
export const DELETE = proxy;
export const OPTIONS = proxy;
