import { timingSafeEqual } from 'crypto';
import { NextRequest } from 'next/server';
import { CopilotRuntime, copilotRuntimeNextJSAppRouterEndpoint } from '@copilotkit/runtime';
import { SyllabotAdapter } from './syllabot-adapter';
import { SESSION_COOKIE, fetchSessionUser } from '../auth/session';

export const runtime = 'nodejs';

const backendUrl = process.env.BACKEND_INTERNAL_URL || 'http://localhost:3000';
const copilotRuntime = new CopilotRuntime();

function isInternalCall(request: NextRequest): boolean {
  const expected = process.env.ADMIN_API_KEY || '';
  const provided = request.headers.get('x-admin-key') || '';
  return expected.length > 0 && expected.length === provided.length
    && timingSafeEqual(Buffer.from(expected), Buffer.from(provided));
}

export async function POST(request: NextRequest) {
  if (!isInternalCall(request) && !(await fetchSessionUser(request.cookies.get(SESSION_COOKIE)?.value))) {
    return Response.json({ error: 'Inicia sesión para usar el copiloto' }, { status: 401 });
  }

  const apiKey = process.env.OPENROUTER_API_KEY;
  if (!apiKey) {
    return Response.json({ error: 'OPENROUTER_API_KEY no está configurada en el frontend' }, { status: 500 });
  }

  const serviceAdapter = new SyllabotAdapter(backendUrl, apiKey);
  const { handleRequest } = copilotRuntimeNextJSAppRouterEndpoint({
    runtime: copilotRuntime,
    serviceAdapter,
    endpoint: '/api/copilotkit',
  });

  return handleRequest(request);
}
