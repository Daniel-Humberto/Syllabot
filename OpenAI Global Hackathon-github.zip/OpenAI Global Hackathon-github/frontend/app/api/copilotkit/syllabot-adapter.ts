import { randomUUID } from 'crypto';
import { createOpenAI } from '@ai-sdk/openai';
import type { LanguageModel } from 'ai';
import type {
  CopilotServiceAdapter,
  CopilotRuntimeChatCompletionRequest,
  CopilotRuntimeChatCompletionResponse,
} from '@copilotkit/runtime';

/**
 * Adaptador que conecta el runtime de CopilotKit con Syllabot.
 *
 * IMPORTANTE (CopilotKit >=1.7x, runtime v2): si `getLanguageModel()` no está
 * implementado, el runtime crea un `BuiltInAgent` a partir de `provider`/`model`
 * que llama DIRECTO a la API real del proveedor (aquí explotaba pidiendo
 * OPENAI_API_KEY) e ignora por completo `process()`. Por eso exponemos aquí un
 * LanguageModel real apuntando a OpenRouter (compatible con la API de OpenAI)
 * usando la misma OPENROUTER_API_KEY que ya usa el backend — así el sidebar de
 * CopilotKit responde con el mismo proveedor/modelo que el resto de Syllabot.
 *
 * `process()` se conserva por compatibilidad con la interfaz, pero mientras
 * `getLanguageModel()` esté presente el runtime no lo invoca para el chat del
 * sidebar; el RAG (Qdrant/Neo4j) sigue disponible completo en la pestaña
 * "Agent Console" del dashboard (que sí llama a /chat) y en Telegram/Discord.
 */
export class SyllabotAdapter implements CopilotServiceAdapter {
  name = 'SyllabotAdapter';

  constructor(
    private readonly backendUrl: string,
    private readonly openRouterApiKey: string,
    private readonly modelId = process.env.OPENROUTER_MODEL || 'openai/gpt-4o-mini'
  ) {}

  getLanguageModel(): LanguageModel {
    const openRouter = createOpenAI({
      baseURL: 'https://openrouter.ai/api/v1',
      apiKey: this.openRouterApiKey,
    });
    return openRouter(this.modelId);
  }

  async process(
    request: CopilotRuntimeChatCompletionRequest
  ): Promise<CopilotRuntimeChatCompletionResponse> {
    const { eventSource, messages, threadId: threadIdFromRequest } = request;
    const threadId = threadIdFromRequest ?? randomUUID();

    const lastUserMessage = [...messages]
      .reverse()
      .find((message) => message.isTextMessage() && message.role === 'user');
    const text = lastUserMessage && lastUserMessage.isTextMessage() ? lastUserMessage.content : '';

    eventSource.stream(async (eventStream$) => {
      const messageId = randomUUID();
      eventStream$.sendTextMessageStart({ messageId });

      try {
        const response = await fetch(`${this.backendUrl}/chat`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ message: text, sessionId: `copilotkit:${threadId}` }),
          signal: AbortSignal.timeout(60_000),
        });
        const data = await response.json().catch(() => ({}));
        const content = response.ok
          ? String(data.output || 'El agente no devolvió contenido.')
          : `No pude procesar el mensaje: ${data.error || `HTTP ${response.status}`}`;
        eventStream$.sendTextMessageContent({ messageId, content });
      } catch (error) {
        eventStream$.sendTextMessageContent({
          messageId,
          content: `No pude conectar con Syllabot: ${error instanceof Error ? error.message : 'error desconocido'}`,
        });
      }

      eventStream$.sendTextMessageEnd({ messageId });
      eventStream$.complete();
    });

    return { threadId };
  }
}
