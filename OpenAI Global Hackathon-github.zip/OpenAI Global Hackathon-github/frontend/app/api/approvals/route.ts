import { NextRequest, NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  const adminKey = process.env.ADMIN_API_KEY;
  if (!adminKey) return NextResponse.json({ error: 'Administración no configurada' }, { status: 503 });
  if (request.headers.get('x-admin-key') !== adminKey) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
  const backend = process.env.BACKEND_INTERNAL_URL || 'http://localhost:3000';
  const response = await fetch(`${backend}/approvals?status=pending`, {
    headers: { 'x-admin-key': adminKey },
    cache: 'no-store',
  });
  const body = await response.json().catch(() => ({ error: 'Respuesta inválida del backend' }));
  return NextResponse.json(body, { status: response.status });
}
