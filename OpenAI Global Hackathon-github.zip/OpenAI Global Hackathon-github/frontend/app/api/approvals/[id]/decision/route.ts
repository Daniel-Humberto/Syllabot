import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  const adminKey = process.env.ADMIN_API_KEY;
  if (!adminKey) return NextResponse.json({ error: 'Administración no configurada' }, { status: 503 });
  if (request.headers.get('x-admin-key') !== adminKey) return NextResponse.json({ error: 'No autorizado' }, { status: 401 });
  const backend = process.env.BACKEND_INTERNAL_URL || 'http://localhost:3000';
  const { id } = await context.params;
  const payload = await request.json();
  const response = await fetch(`${backend}/approvals/${encodeURIComponent(id)}/decision`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-admin-key': adminKey },
    body: JSON.stringify(payload),
  });
  const body = await response.json().catch(() => ({ error: 'Respuesta inválida del backend' }));
  return NextResponse.json(body, { status: response.status });
}
